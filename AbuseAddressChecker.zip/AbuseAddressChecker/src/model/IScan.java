package model;

import java.util.ArrayList;

public interface IScan {
	public void SaveScan(ArrayList<ScanItem> scan);
}
