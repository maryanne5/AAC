package model;

import java.util.ArrayList;

public class NullScan implements IScan {

	@Override
	public void SaveScan(ArrayList<ScanItem> report) {
				
	}

}
